package host

func getHostShellCmd() []string {
	return []string{"/bin/bash", "-l"}
}
