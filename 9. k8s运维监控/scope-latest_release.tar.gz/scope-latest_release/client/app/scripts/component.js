module.exports = require('./components/app').default;
