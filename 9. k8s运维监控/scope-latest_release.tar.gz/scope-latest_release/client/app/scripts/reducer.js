module.exports = require('./reducers/root').default;
